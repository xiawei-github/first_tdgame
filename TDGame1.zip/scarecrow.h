#ifndef SCARECROW_H
#define SCARECROW_H
#include "rpgobj.h"
#include <QMediaPlayer>

class Scarecrow : public RPGObj
{
public:
    Scarecrow();
    ~Scarecrow();
    void onErase();
};

#endif // SCARECROW_H

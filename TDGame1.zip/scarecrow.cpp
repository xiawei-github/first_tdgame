#include "scarecrow.h"

Scarecrow::Scarecrow()
{

}

Scarecrow::~Scarecrow()
{

}

void Scarecrow::onErase(){
    QMediaPlayer * player = new QMediaPlayer;
    //player->setMedia(QUrl("qrc:/sounds/crash.mp3"));
    player->setVolume(30);
    player->play();
}

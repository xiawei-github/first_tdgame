#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "icon.h"
#include <QTime>
#include<QTimer>
#include <map>
#include <iostream>

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    //init game world
    _game.initWorld("");//TODO Ӧ����������Ч�ĵ�ͼ�ļ�

    timer = new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(handlePlayerMove()));
        //randomMove()Ϊ�Զ���ۺ���
    timer->start(50);
    timer->setInterval(500);

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));//�����������
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *e){
    //Painter painter(this);
    //painter.drawPixmap(0, 0, QPixmap(":/pictures/map.png"));
    QPainter *pa;
    pa = new QPainter();
    pa->begin(this);
    this->_game.show(pa);
    pa->end();
    delete pa;
}

void MainWindow::keyPressEvent(QKeyEvent *e)
{
    //direction = 1,2,3,4 for ��������
    if(e->key() == Qt::Key_A)
    {
        this->_game.handlePlayerMove(3,1);
    }
    else if(e->key() == Qt::Key_D)
    {
        this->_game.handlePlayerMove(4,1);
    }
    else if(e->key() == Qt::Key_W)
    {
        this->_game.handlePlayerMove(1,1);
    }
    else if(e->key() == Qt::Key_S)
    {
         this->_game.handlePlayerMove(2,1);
    }
    this->repaint();
}

void MainWindow::randomMove(){

    int d = 1 + rand()%4;//��������˶��ķ���
    this->_game.handlePlayerMove(d,1);
    this->repaint();
}

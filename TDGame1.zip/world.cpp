#include "world.h"
#include "icon.h"
#include "rpgobj.h"
#include <QMediaPlayer>
#include<iostream>
using namespace std;

World::~World(){
    delete this->_snowman;
}

void World::initWorld(string mapFile){
    //TODO ���������Ӧ�ø�Ϊ�ӵ�ͼ�ļ�װ��
    //player 5 5
    this->_snowman->initObj("snowman");
    this->_snowman->setPosX(0);
    this->_snowman->setPosY(12);

    RPGObj *p1 = new Scarecrow;
    p1->initObj("scarecrow");
    p1->setPosX(6);
    p1->setPosY(8);

    this->_objs.push_back(p1);
    /*
    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/sounds/hdl.mp3"));
    player->setVolume(30);
    player->play();
    */

}


void World::show(QPainter * painter){
    int n = this->_objs.size();
    for (int i=0;i<n;i++){
        this->_objs[i]->show(painter);
    }
    this->_snowman->show(painter);



}

void World::eraseObj(int x, int y){
    vector<RPGObj*>::iterator it;
    it = _objs.begin();
    while(it!=_objs.end()){
        int flag1 = ((*it)->getObjType()!="scarecrow"); //����ʯͷ
        int flag2 = ((*it)->getPosX() == x) && ((*it)->getPosY()==y);//λ���ص�

        if (flag1 && flag2){
            cout<<(*it)->getObjType()<<endl;
            (*it)->onErase();
            delete (*it);
            it = this->_objs.erase(it);
            break;
         }
        else{
            it++;
        }
    }

}

void World::handlePlayerMove(int direction, int steps){
    int x =  this->_snowman->getNextX(direction);
    int y = this->_snowman->getNextY(direction);
    this->eraseObj(x,y);
    this->_snowman->move(direction, steps);
}

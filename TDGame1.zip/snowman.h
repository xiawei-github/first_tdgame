#ifndef SNOWMAN_H
#define SNOWMAN_H
#include "rpgobj.h"

class Snowman: public RPGObj
{
public:
    Snowman(){}
    ~Snowman(){}
    void move(int direction, int steps=1);
        //direction =1,2,3,4 for ��������
};

#endif // SNOWMAN_H

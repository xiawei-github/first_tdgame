#include "tower.h"
#include <QPoint>
#include <QPixmap>
#include <QPainter>

Tower::Tower(QPoint pos,QString pixFileName) : QObject(0),pixmap(pixFileName)
{
    _pos = pos;
    QSize picSize(120,160);
    QPixmap scaledPixmap = pixmap.scaled(picSize,Qt::KeepAspectRatio);
    pixmap = scaledPixmap;
}

void Tower::draw(QPainter *painter){
    painter->drawPixmap(_pos,pixmap);
}

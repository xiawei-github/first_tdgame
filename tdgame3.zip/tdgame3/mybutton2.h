#ifndef MYBUTTON2_H
#define MYBUTTON2_H

#include <QWidget>
#include <QPushButton>

class MyButton2 : public QPushButton
{
    Q_OBJECT
public:
    MyButton2(QString pix);

signals:

public slots:
};

#endif // MYBUTTON2_H

#include "mywindow.h"
#include "mybutton.h"
#include "mybutton2.h"
#include <QPainter>
#include <QPixmap>

MyWindow::MyWindow(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(1500,900);
    MyButton * back_btn = new MyButton(":/anniu.png");
    back_btn->setParent(this);
    back_btn->move(20,730);

    MyButton2 * setTower1 = new MyButton2(":/anniu2.png");
    setTower1->setParent(this);
    setTower1->move(350,450);
    connect(setTower1,&MyButton2::clicked,this,&MyWindow::set_tower1);

    MyButton2 * setTower2 = new MyButton2(":/anniu2.png");
    setTower2->setParent(this);
    setTower2->move(350,260);
    connect(setTower2,&MyButton2::clicked,this,&MyWindow::set_tower2);

    MyButton2 * setTower3 = new MyButton2(":/anniu2.png");
    setTower3->setParent(this);
    setTower3->move(530,630);
    connect(setTower3,&MyButton2::clicked,this,&MyWindow::set_tower3);

    MyButton2 * setTower4 = new MyButton2(":/anniu2.png");
    setTower4->setParent(this);
    setTower4->move(1200,630);
    connect(setTower4,&MyButton2::clicked,this,&MyWindow::set_tower4);

    MyButton2 * setTower5 = new MyButton2(":/anniu2.png");
    setTower5->setParent(this);
    setTower5->move(560,160);
    connect(setTower5,&MyButton2::clicked,this,&MyWindow::set_tower5);

    MyButton2 * setTower6 = new MyButton2(":/anniu2.png");
    setTower6->setParent(this);
    setTower6->move(970,160);
    connect(setTower6,&MyButton2::clicked,this,&MyWindow::set_tower6);

    MyButton2 * setTower7 = new MyButton2(":/anniu2.png");
    setTower7->setParent(this);
    setTower7->move(1200,340);
    connect(setTower7,&MyButton2::clicked,this,&MyWindow::set_tower7);

    MyButton2 * setTower8 = new MyButton2(":/anniu2.png");
    setTower8->setParent(this);
    setTower8->move(860,340);
    connect(setTower8,&MyButton2::clicked,this,&MyWindow::set_tower8);

    connect(back_btn,&MyButton::clicked,this,[=](){
        emit chooseBack();
    });
}

void MyWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/map.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    foreach(Tower * tower, tower_list)
        tower->draw(&painter);
    update();
}

void MyWindow::set_tower1(){
    Tower * a_new_tower = new Tower(QPoint(380,390),":/tower.png");
    tower_list.push_back(a_new_tower);
}

void MyWindow::set_tower2(){
    Tower * a_new_tower = new Tower(QPoint(380,200),":/tower.png");
    tower_list.push_back(a_new_tower);
}
void MyWindow::set_tower3(){
    Tower * a_new_tower = new Tower(QPoint(560,570),":/tower.png");
    tower_list.push_back(a_new_tower);
}

void MyWindow::set_tower4(){
    Tower * a_new_tower = new Tower(QPoint(1110,570),":/tower.png");
    tower_list.push_back(a_new_tower);
}

void MyWindow::set_tower5(){
    Tower * a_new_tower = new Tower(QPoint(590,100),":/tower.png");
    tower_list.push_back(a_new_tower);
}

void MyWindow::set_tower6(){
    Tower * a_new_tower = new Tower(QPoint(880,100),":/tower.png");
    tower_list.push_back(a_new_tower);
}

void MyWindow::set_tower7(){
    Tower * a_new_tower = new Tower(QPoint(1110,280),":/tower.png");
    tower_list.push_back(a_new_tower);
}

void MyWindow::set_tower8(){
    Tower * a_new_tower = new Tower(QPoint(770,280),":/tower.png");
    tower_list.push_back(a_new_tower);
}

#ifndef MYWINDOW_H
#define MYWINDOW_H

#include <QMainWindow>
#include "tower.h"
#include <QList>
#include "enemy.h"
#include "enemy2.h"
#include "mybutton2.h"
#include "bullet.h"
#include "towerposition.h"
#include "tower2.h"

class WayPoint;
class Enemy2;
class Tower;
class MyButton2;
class Bullet;
class Tower2;
class MyWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MyWindow(int round, QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
    //void addEnemy();
    void updateScene();
    void removedEnemy(Enemy2 *enemy);
    void removedBullet(Bullet *bullet);
    void addBullet(Bullet *bullet);
    void getHpDamage(int damage = 1);
    void awardGold(int gold);
    friend class MyButton2;
    friend class Bullet;
    QList<Enemy2*> enemyList() const;
    QList<Enemy2*> enemy2_list;

private:
    QList<Tower*> tower_list;
    QList<Tower2*> tower2_list;
    QList<Enemy*> enemy_list;
    //QList<Enemy2*> enemy2_list;
    QList<Bullet*> bullet_list;
    int	waves;
    int	playerHp;
    int	playrGold;
    bool gameEnded;
    bool gameWin;
    QList<QVariant>	wavesInfo;
    QList<TowerPosition> towerPositionsList;
    QList<WayPoint *> wayPointsList;
    int round;

private:
    void loadTowerPositions();
    void addWayPoints();
    bool loadWave();
    bool canBuyTower() const;
    void drawWave(QPainter *painter);
    void drawHP(QPainter *painter);
    void drawPlayerGold(QPainter *painter);
    void doGameOver();
    void preLoadWavesInfo();

protected:
    void mousePressEvent(QMouseEvent *);

signals:
    void chooseBack();

public slots:
    //void set_tower(MyButton2 *btn);
private slots:
    void updateMap();
    void gameStart();
};

#endif // MYWINDOW_H

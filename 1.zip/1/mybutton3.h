#ifndef MYBUTTON3_H
#define MYBUTTON3_H

#include <QWidget>
#include <QPushButton>

class MyButton3 : public QPushButton
{
    Q_OBJECT
public:
    MyButton3(QString pix);

signals:

public slots:
};

#endif // MYBUTTON3_H

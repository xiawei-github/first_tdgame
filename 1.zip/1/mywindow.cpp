#include "mywindow.h"
#include "mybutton.h"
#include "mybutton2.h"
#include "mybutton3.h"
#include <QPainter>
#include <QPixmap>
#include <QTimer>
#include "enemy.h"
#include "enemy2.h"
#include "bullet.h"
#include <QDebug>
#include <QtDebug>
#include "waypoint.h"
#include <cassert>
#include <QMouseEvent>
#include <QtGlobal>
#include <QMessageBox>
#include <QXmlStreamReader>
#include <stdlib.h>
#include <time.h>

static const int TowerCost = 400;

MyWindow::MyWindow(int round, QWidget *parent) : QMainWindow(parent)
{
    this->waves = 0;
    this->playerHp = 5;
    this->playrGold = 1000;
    this->gameEnded = false;
    this->gameWin = false;
    this->round = round;

    this->setFixedSize(1500,900);
    loadTowerPositions();
    addWayPoints();
    MyButton * back_btn = new MyButton(":/anniu.png");
    back_btn->setParent(this);
    back_btn->move(20,730);

    connect(back_btn,&MyButton::clicked,this,[=](){
        emit chooseBack();
    });

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateMap()));
    timer->start(30);

    // �����ť����Ϸ����
    MyButton * startButton = new MyButton(":/startbutton1.png");
    startButton->setParent(this);
    startButton->move(0,180);
    connect(startButton,&MyButton::clicked,this,[=](){
        startButton->zoomdown();
        startButton->zoomup();
        QTimer::singleShot(300,this,[=](){
            this->gameStart();
        });
    });

    /*
    MyButton3 * setEnemy = new MyButton3(":/anniu3.png");
    setEnemy->setParent(this);
    setEnemy->move(0,100);
    connect(setEnemy,&MyButton3::clicked,this,&MyWindow::addEnemy);
    */
    /*
    QTimer * timer1 = new QTimer(this);
    connect(timer1,&QTimer::timeout,this,&MyWindow::addEnemy);
    timer1->start(3000);

    connect(back_btn,&MyButton::clicked,this,[=](){
        emit chooseBack();
    });

    QPoint pos1(350,450);
    MyButton2 * menuBtn1 = new MyButton2(":/anniu2.png",pos1,this);
    menuBtn1->setParent(this);
    connect(menuBtn1,&MyButton2::chooseSetTower,menuBtn1,&MyButton2::set_tower1);
    //connect(menuBtn1,&MyButton2::chooseDeleteTower,menuBtn1,&MyButton2::delete_tower);

    QPoint pos2(350,260);
    MyButton2 * menuBtn2 = new MyButton2(":/anniu2.png",pos2,this);
    menuBtn2->setParent(this);
    connect(menuBtn2,&MyButton2::chooseSetTower,menuBtn2,&MyButton2::set_tower1);

    QPoint pos3(530,630);
    MyButton2 * menuBtn3 = new MyButton2(":/anniu2.png",pos3,this);
    menuBtn3->setParent(this);
    connect(menuBtn3,&MyButton2::chooseSetTower,menuBtn3,&MyButton2::set_tower1);

    QPoint pos4(1200,630);
    MyButton2 * menuBtn4 = new MyButton2(":/anniu2.png",pos4,this);
    menuBtn4->setParent(this);
    connect(menuBtn4,&MyButton2::chooseSetTower,menuBtn4,&MyButton2::set_tower2);

    QPoint pos5(560,160);
    MyButton2 * menuBtn5 = new MyButton2(":/anniu2.png",pos5,this);
    menuBtn5->setParent(this);
    connect(menuBtn5,&MyButton2::chooseSetTower,menuBtn5,&MyButton2::set_tower1);

    QPoint pos6(970,160);
    MyButton2 * menuBtn6 = new MyButton2(":/anniu2.png",pos6,this);
    menuBtn6->setParent(this);
    connect(menuBtn6,&MyButton2::chooseSetTower,menuBtn6,&MyButton2::set_tower2);

    QPoint pos7(1200,340);
    MyButton2 * menuBtn7 = new MyButton2(":/anniu2.png",pos7,this);
    menuBtn7->setParent(this);
    connect(menuBtn7,&MyButton2::chooseSetTower,menuBtn7,&MyButton2::set_tower2);

    QPoint pos8(860,340);
    MyButton2 * menuBtn8 = new MyButton2(":/anniu2.png",pos8,this);
    menuBtn8->setParent(this);
    connect(menuBtn8,&MyButton2::chooseSetTower,menuBtn8,&MyButton2::set_tower2);

    QTimer * timer = new QTimer(this);
    connect(timer,&QTimer::timeout,this,&MyWindow::updateScene);
    timer->start(10);*/
    /*
    QTimer * timer0 = new QTimer(this);
    connect(timer0, SIGNAL(timeout()), this, SLOT(updateMap()));
    timer0->start(10);
*/
}

void MyWindow::paintEvent(QPaintEvent *){
    if (gameEnded || gameWin)
    {
        QString text = gameEnded ? "YOU LOST!!!" : "YOU WIN!!!";
        QPainter painter(this);
        painter.setPen(QPen(Qt::red));
        painter.setFont(QFont("Calibri",24));
        painter.drawText(rect(), Qt::AlignCenter, text);
        return;
    }

    QPainter painter(this);
    if(round == 1){
        QPixmap pixmap(":/map1.png");
        painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    }
    else if(round == 2){
        QPixmap pixmap(":/map2.png");
        painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    }
    foreach(Tower * tower, tower_list)
        tower->draw(&painter);
    foreach(Enemy * enemy, enemy_list)
        enemy->draw(&painter);
    foreach(Enemy2* enemy, enemy2_list)
        enemy->draw(&painter);
    foreach(Bullet* bullet, bullet_list)
        bullet->draw(&painter);
    foreach(const TowerPosition &towerPos, towerPositionsList)
        towerPos.draw(&painter);
    foreach(const WayPoint *wayPoint, wayPointsList)
        wayPoint->draw(&painter);
    foreach(Tower2 * tower2, tower2_list)
        tower2->draw(&painter);

    drawWave(&painter);
    drawHP(&painter);
    drawPlayerGold(&painter);
}

QList<Enemy2 *> MyWindow::enemyList() const{
    return enemy2_list;
}

void MyWindow::updateMap(){
    foreach(Enemy2 *enemy, enemy2_list)
        enemy->move();
    foreach(Tower *tower, tower_list)
        tower->checkEnemyInRange();
    foreach(Tower2 *tower2, tower2_list){
        tower2->chooseEnemyforAttack();
    }
    update();
}

void MyWindow::loadTowerPositions(){
    if(round == 1){
        QPoint pos[] =
        {
            QPoint(200,580),
            QPoint(200,450),
            QPoint(600,580),
            QPoint(460,160),
            QPoint(700,450)
        };
        int len	= sizeof(pos) / sizeof(pos[0]);
        for (int i = 0; i < len; ++i){
            towerPositionsList.push_back(pos[i]);
        }
    }
    else if(round == 2){
        QPoint pos[] =
        {
            QPoint(600,610),
            QPoint(460,260),
            QPoint(980,450),
            QPoint(740,450)
        };
        int len	= sizeof(pos) / sizeof(pos[0]);
        for (int i = 0; i < len; ++i){
            towerPositionsList.push_back(pos[i]);
        }
    }
}

void MyWindow::mousePressEvent(QMouseEvent *event){
    QPoint pressPos = event->pos();
    auto it = towerPositionsList.begin();
    while (it != towerPositionsList.end()){
        if (canBuyTower() && it->containPoint(pressPos) && !it->hasTower()){
            //��������������������ڰ�ť�ϲ���׼��������û����������Խ���
            playrGold -= TowerCost; //���������
            it->setHasTower(); //��ʾ����

            if(event->button()==Qt::LeftButton){ //��������ܹ��������˵���
                Tower *tower = new Tower(it->centerPos(), this, ":/tower.png");
                tower_list.push_back(tower);
                update();
                break;
            }
            else if(event->button()==Qt::RightButton){ //�Ҽ������ܹ�ʹ���˼��ٵ���
                Tower2 *tower2 = new Tower2(it->centerPos(), this, ":/tower2.png");
                tower2_list.push_back(tower2);
                update();
                break;
            }
        }
        else if(it->containPoint(pressPos)&&it->hasTower()){
            //��������ť���ҽ��������������ǲ��������������
            if(event->button()==Qt::LeftButton){ //���������
                foreach(Tower *tower, tower_list){
                    if(it->containPoint(tower->getpos()+QPoint(0,30))&&playrGold>=TowerCost/2&&tower->level()<=1){
                        if(tower->level()==1){
                            tower->levelup1();
                        }
                        else if(tower->level()==2){
                            tower->levelup2();
                        }
                        playrGold-=TowerCost/2;
                    }
                }
            }
            else if(event->button()==Qt::RightButton){ //�Ҽ������
                foreach(Tower *tower, tower_list){
                    if(it->containPoint(tower->getpos())){
                        it->setHasnotTower();
                        tower_list.removeOne(tower);
                        playrGold += (tower->level()+1)*TowerCost/2;
                        delete(tower);
                    }
                }
                foreach(Tower2 *tower, tower2_list){
                    if(it->containPoint(tower->getpos())){
                        it->setHasnotTower();
                        tower2_list.removeOne(tower);
                        playrGold += TowerCost;
                        delete(tower);
                    }
                }
            }
            update();
            break;
        }
        ++it;
    }
}

bool MyWindow::canBuyTower() const{
    if (playrGold >= TowerCost){
        return true;
    }
    return false;
}

void MyWindow::drawWave(QPainter *painter){
    painter->setPen(QPen(Qt::red));
    painter->setFont(QFont("Calibri",24));
    painter->drawText(QRect(500, 5, 200, 50), QString("WAVE : %1").arg(waves + 1));
}

void MyWindow::drawHP(QPainter *painter){
    painter->setPen(QPen(Qt::red));
    painter->setFont(QFont("Calibri",24));
    painter->drawText(QRect(30, 5, 200, 50), QString("HP : %1").arg(playerHp));
}

void MyWindow::drawPlayerGold(QPainter *painter){
    painter->setPen(QPen(Qt::red));
    painter->setFont(QFont("Calibri",24));
    painter->drawText(QRect(200, 5, 400, 50), QString("GOLD : %1").arg(playrGold));
}

void MyWindow::doGameOver(){
    if (!gameEnded)
    {
        gameEnded = true;
        // �˴�Ӧ���л���������������
        // ��ʱ�Դ�ӡ���,��paintEvent����
    }
}

void MyWindow::awardGold(int gold){
    playrGold += gold;
    update();
}

void MyWindow::addWayPoints(){
    if(round == 1){
        WayPoint *wayPoint1 = new WayPoint(QPoint(1000, 640));
        wayPointsList.push_back(wayPoint1);

        WayPoint *wayPoint2 = new WayPoint(QPoint(100, 640));
        wayPointsList.push_back(wayPoint2);
        wayPoint2->setNextWayPoint(wayPoint1);

        WayPoint *wayPoint3 = new WayPoint(QPoint(100, 350));
        wayPointsList.push_back(wayPoint3);
        wayPoint3->setNextWayPoint(wayPoint2);

        WayPoint *wayPoint4 = new WayPoint(QPoint(770, 350));
        wayPointsList.push_back(wayPoint4);
        wayPoint4->setNextWayPoint(wayPoint3);

        WayPoint *wayPoint5 = new WayPoint(QPoint(770, 70));
        wayPointsList.push_back(wayPoint5);
        wayPoint5->setNextWayPoint(wayPoint4);

        WayPoint *wayPoint6 = new WayPoint(QPoint(100, 70));
        wayPointsList.push_back(wayPoint6);
        wayPoint6->setNextWayPoint(wayPoint5);

        WayPoint *wayPoint7 = new WayPoint(QPoint(100, 0));
        wayPointsList.push_back(wayPoint7);
        wayPoint7->setNextWayPoint(wayPoint6);
    }
    else if(round == 2){
        WayPoint *wayPoint1 = new WayPoint(QPoint(1140, 300));
        wayPointsList.push_back(wayPoint1);

        WayPoint *wayPoint2 = new WayPoint(QPoint(1140, 480));
        wayPointsList.push_back(wayPoint2);
        wayPoint2->setNextWayPoint(wayPoint1);

        WayPoint *wayPoint3 = new WayPoint(QPoint(900, 480));
        wayPointsList.push_back(wayPoint3);
        wayPoint3->setNextWayPoint(wayPoint2);

        WayPoint *wayPoint4 = new WayPoint(QPoint(900, 310));
        wayPointsList.push_back(wayPoint4);
        wayPoint4->setNextWayPoint(wayPoint3);

        WayPoint *wayPoint5 = new WayPoint(QPoint(430, 310));
        wayPointsList.push_back(wayPoint5);
        wayPoint5->setNextWayPoint(wayPoint4);

        WayPoint *wayPoint6 = new WayPoint(QPoint(430, 480));
        wayPointsList.push_back(wayPoint6);
        wayPoint6->setNextWayPoint(wayPoint5);

        WayPoint *wayPoint7 = new WayPoint(QPoint(710, 480));
        wayPointsList.push_back(wayPoint7);
        wayPoint7->setNextWayPoint(wayPoint6);

        WayPoint *wayPoint8 = new WayPoint(QPoint(710, 650));
        wayPointsList.push_back(wayPoint8);
        wayPoint8->setNextWayPoint(wayPoint7);

        WayPoint *wayPoint9 = new WayPoint(QPoint(290, 650));
        wayPointsList.push_back(wayPoint9);
        wayPoint9->setNextWayPoint(wayPoint8);

        WayPoint *wayPoint10 = new WayPoint(QPoint(290, 800));
        wayPointsList.push_back(wayPoint10);
        wayPoint10->setNextWayPoint(wayPoint9);
    }
}

void MyWindow::getHpDamage(int damage/* = 1*/){
    playerHp -= damage;
    if (playerHp <= 0){
        doGameOver();
    }
}

void MyWindow::removedEnemy(Enemy2 *enemy){
    Q_ASSERT(enemy);
    enemy2_list.removeOne(enemy);
    delete enemy;
    if (enemy2_list.empty())
    {
        ++waves;
        if (!loadWave()){
            gameWin = true;
            // ��Ϸʤ��ת����Ϸʤ������
            // ������ʱ�Դ�ӡ����
        }
    }
}

void MyWindow::removedBullet(Bullet *bullet){
    Q_ASSERT(bullet);
    bullet_list.removeOne(bullet);
    delete bullet;
}

void MyWindow::addBullet(Bullet *bullet){
    Q_ASSERT(bullet);
    bullet_list.push_back(bullet);
}


bool MyWindow::loadWave(){
    WayPoint *startWayPoint = wayPointsList.back();
    int enemyStartInterval1[] = {1500, 3000};
    int enemyStartInterval2[] = {1000, 4000, 6000, 8000, 10000};
    int enemyStartInterval3[] = {1000, 2000, 3000, 4000, 5000, 6000, 7000};

    int enemyStartInterval4[] = {1500, 3000, 4500};
    int enemyStartInterval5[] = {1000, 4000, 6000, 8000, 10000, 12000, 14000};
    int enemyStartInterval6[] = {1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000};
    QPixmap pixmap1(":/enemy2.png");
    QPixmap pixmap2(":/enemy3.png");

    if(round == 1){
        if (waves >= 7){
            return false;
        }
        else{
            if(waves == 0){
                for(int i = 0; i < 2; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint,this, 2.8, 80, pixmap1);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval1[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 1){
                for(int i = 0; i < 2; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint,this, 3.2, 100, pixmap2);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval1[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 2){
                for (int i = 0; i < 5; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint, this, 3.2, 100, pixmap1);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval2[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 3){
                for (int i = 0; i < 5; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint, this, 3.5, 120, pixmap2);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval2[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 4){
                for (int i = 0; i < 7; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint, this, 3.5, 120, pixmap1);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval3[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 5){
                for (int i = 0; i < 7; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint, this, 3.8, 150, pixmap2);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval3[i], enemy, SLOT(doActivate()));
                }
            }
            return true;
        }
    }

    else if(round == 2){
        if (waves >= 7){
            return false;
        }
        else{
            if(waves == 0){
                for(int i = 0; i < 3; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint,this, 3.0, 100, pixmap1);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval4[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 1){
                for(int i = 0; i < 3; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint,this, 3.4, 120, pixmap2);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval4[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 2){
                for (int i = 0; i < 7; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint, this, 3.4, 120, pixmap1);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval5[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 3){
                for (int i = 0; i < 7; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint, this, 3.8, 150, pixmap2);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval5[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 4){
                for (int i = 0; i < 10; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint, this, 3.8, 150, pixmap1);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval6[i], enemy, SLOT(doActivate()));
                }
            }
            else if(waves == 5){
                for (int i = 0; i < 10; ++i){
                    Enemy2 *enemy = new Enemy2(startWayPoint, this, 4.2, 180, pixmap2);
                    enemy2_list.push_back(enemy);
                    QTimer::singleShot(enemyStartInterval6[i], enemy, SLOT(doActivate()));
                }
            }
            return true;
        }
    }
}

void MyWindow::gameStart()
{
    loadWave();
}

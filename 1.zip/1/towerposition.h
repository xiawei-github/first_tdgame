#ifndef TOWERPOSITION_H
#define TOWERPOSITION_H

#include <QPoint>
#include <QSize>
#include <QPixmap>

class QPainter;

class TowerPosition
{
public:
    TowerPosition(QPoint pos, const QPixmap &sprite = QPixmap(":/anniu4.png"));
    //TowerPosition(QPoint pos, QString fileName);
    void setHasTower(bool hasTower = true);
    bool hasTower() const;
    const QPoint centerPos() const;
    bool containPoint(const QPoint &pos) const;
    void draw(QPainter *painter) const;
    void setHasnotTower(bool hasTower= false);

private:
    bool hasTower0;
    QPoint pos0;
    QPixmap	sprite;

    static const QSize ms_fixedSize;
};

#endif // TOWERPOSITION_H

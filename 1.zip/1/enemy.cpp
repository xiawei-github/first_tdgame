#include "enemy.h"

Enemy::Enemy(QPoint startPos, QPoint targetPos, QString fileName): QObject(0), pixmap(fileName)
{
    this->currentPos = startPos;
    this->startPos = startPos;
    this->targetPos = targetPos;
    QSize picSize(120,160);
    QPixmap scaledPixmap = pixmap.scaled(picSize,Qt::KeepAspectRatio);
    pixmap = scaledPixmap;
}

void Enemy::draw(QPainter *painter){
    painter->drawPixmap(currentPos,pixmap);
}

void Enemy::move(){
    QPropertyAnimation * animation = new QPropertyAnimation(this,"currentPos");
    animation->setDuration(2000);
    animation->setStartValue(startPos);
    animation->setEndValue(targetPos);
    animation->start();
}

QPoint Enemy::getCurrentPos(){
    return this->currentPos;
}

void Enemy::setCurrentPos(QPoint pos){
    this->currentPos = pos;
}

#include "enemy2.h"
#include <QPoint>
#include <QVector2D>
#include <QPainter>
#include <stdlib.h>
#include <time.h>
#include "waypoint.h"
#include "utility.h"
#include "mywindow.h"
#include <QColor>
#include <QDebug>
#include <QMatrix>
#include <QVector2D>
#include <QtMath>

const QSize Enemy2::fixedSize(52, 52);

Enemy2::Enemy2(WayPoint *startWayPoint, MyWindow *game, qreal speed, int blood, const QPixmap &sprite/* = QPixmap(":/enemy2.png")*/): QObject(0), pixmap(sprite)
{
    this->setPos();
    this->startPos = pos[0];
    this->currentPos = this->_pos;
    this->targetPos = pos[1];
    this->speed = speed;
    this->active = false;
    this->maxBlood = blood;
    this->currentBlood = blood;
    this->rotationSprite = 0.0;
    this->_pos = startWayPoint->pos();
    this->destinationWayPoint = startWayPoint->nextWayPoint();
    this->game = game;
    this->enemystop = 2.5;
    QSize picSize(114,152);
    QPixmap scaledPixmap = pixmap.scaled(picSize,Qt::KeepAspectRatio);
    pixmap = scaledPixmap;
}
/*
void Enemy2::move(){
    QVector2D vector(targetPos-startPos);
    QVector2D vector1(currentPos-startPos);
    if(vector1.length() < vector.length()){
        vector.normalize();
        currentPos = currentPos+vector.toPoint() * speed;
    }
    else{
        if(i==6)
            return;
        else{
            i++;
            this->startPos=pos[i];
            this->currentPos=startPos;
            this->targetPos=pos[i+1];
            QVector2D vector(targetPos-startPos);
            vector.normalize();
            currentPos = currentPos+vector.toPoint() * speed;
        }
    }
}
*/
void Enemy2::move(){
    if(!active){
        return;
    }
    if(collisionWithCircle(_pos, 1, destinationWayPoint->pos(), 1)){
        // ���˵ִ���һ������
        if(destinationWayPoint->nextWayPoint()){
            // ������һ������
            _pos = destinationWayPoint->pos();
            destinationWayPoint = destinationWayPoint->nextWayPoint();
        }
        else{
            // ��ʾ�������
            game->getHpDamage();
            game->removedEnemy(this);
            return;
        }
    }

    // ����ǰ�������·��
    // Ŀ�꺽�������
    QPoint targetPoint = destinationWayPoint->pos();
    // δ���޸�������������ƶ�״̬,�ӿ�,����,m_walkingSpeed�ǻ�׼ֵ

    // ������׼��
    qreal movementSpeed = speed;
    QVector2D normalized(targetPoint - _pos);
    normalized.normalize();
    _pos = _pos + normalized.toPoint() * movementSpeed;

    // ȷ������ѡ����
    // Ĭ��ͼƬ����,��Ҫ����180��ת��
    rotationSprite = qRadiansToDegrees(qAtan2(normalized.y(), normalized.x())) + 180;
}

void Enemy2::draw(QPainter *painter){
    if (!active)
        return;
    //����Ѫ��
    static const int bloodWidth = 50;
    painter->save();
    QPoint BloodBarPoint = _pos + QPoint(32, -2);
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::red);
    QRect BloodBarBackRect(BloodBarPoint, QSize(bloodWidth, 5));
    painter->drawRect(BloodBarBackRect);
    painter->setBrush(Qt::green);
    QRect BloodBarRect(BloodBarPoint, QSize((double)currentBlood / maxBlood * bloodWidth, 5));
    painter->drawRect(BloodBarRect);

    painter->drawPixmap(_pos,pixmap);
}

void Enemy2::setPos(){
    pos[0].setX(0);
    pos[0].setY(340);
    pos[1].setX(250);
    pos[1].setY(340);
    srand(time(NULL));
    int i=rand();
    if(i % 2 == 1){
        pos[2].setX(250);
        pos[2].setY(170);
        pos[3].setX(470);
        pos[3].setY(170);
        pos[4].setX(470);
        pos[4].setY(65);
        pos[5].setX(1010);
        pos[5].setY(65);
        pos[6].setX(1010);
        pos[6].setY(170);
        pos[7].setX(1250);
        pos[7].setY(170);
    }
    else{
        pos[2].setX(250);
        pos[2].setY(520);
        pos[3].setX(420);
        pos[3].setY(520);
        int j=rand();
        if(j % 2 == 1){
            pos[4].setX(490);
            pos[4].setY(520);
            pos[5].setX(490);
            pos[5].setY(400);
            pos[6].setX(1250);
            pos[6].setY(400);
            pos[7].setX(1250);
            pos[7].setY(170);
        }
        else{
            pos[4].setX(420);
            pos[4].setY(690);
            pos[5].setX(1250);
            pos[5].setY(690);
            pos[6].setX(1250);
            pos[6].setY(170);
            pos[7].setX(1250);
            pos[7].setY(170);
        }
    }
}

void Enemy2::getDamage(int damage){
    currentBlood -= damage;
    // ����,��Ҫ�Ƴ�
    if (currentBlood <= 0){
        game->awardGold(100);
        getRemoved();
    }
}

void Enemy2::getRemoved(){
    if (attackedTowersList.empty()){
        return;
    }
    foreach (Tower * attacker, attackedTowersList)
        attacker->targetKilled();
    // ֪ͨgame,�˵����Ѿ�����
    game->removedEnemy(this);
}

void Enemy2::getAttacked(Tower *attacker){
    attackedTowersList.push_back(attacker);
}

// ���������Ѿ������˹�����Χ
void Enemy2::gotLostSight(Tower *attacker){
    attackedTowersList.removeOne(attacker);
}

QPoint Enemy2::pos0() const{
    return _pos;
}

void Enemy2::doActivate(){
    active = true;
}

void Enemy2::getStopped(qreal enemystop){
    this->enemystop = enemystop;
}

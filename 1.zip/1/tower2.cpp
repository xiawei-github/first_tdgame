#include "tower2.h"
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QVector2D>
#include <QtMath>
#include <QColor>
#include <QTimer>
#include "utility.h"
#include <QList>

const QSize Tower2::ms_fixedSize(100,100);

Tower2::Tower2(QPoint pos, MyWindow * game, QString pixFileName) : QObject(0),pixmap(pixFileName)
{
    this->attackRange = 300;
    this->_pos = pos;
    this->game = game;
    this->enemystop = 2.5;
    QSize picSize(120,160);
    QPixmap scaledPixmap = pixmap.scaled(picSize,Qt::KeepAspectRatio);
    pixmap = scaledPixmap;
}

void Tower2::draw(QPainter *painter){
    painter->save();
    painter->setPen(Qt::blue);
    //painter->drawEllipse(_pos + QPoint(30, -20), attackRange, attackRange);

    painter->drawPixmap(_pos + QPoint(5,-105), pixmap);
    painter->restore();
}

void Tower2::chooseEnemyforAttack(){
    QList<Enemy2 *> enemyList = game->enemy2_list;
    foreach (Enemy2 *enemy1, enemyList)
    {
        if (collisionWithCircle(_pos, attackRange, enemy1->pos0(), 1))
        {
            if(enemystop > enemy1->enemystop){//��ֹ����������ظ�����
                enemy1->getStopped(enemystop);
                chosenEnemyList.push_back(enemy1);
            }
        }
    }
    foreach (Enemy2 *enemy2, chosenEnemyList) {
        if(!collisionWithCircle(_pos, attackRange, enemy2->pos0(), 1)){
            enemy2->enemystop = 0;
            chosenEnemyList.removeOne(enemy2);
        }
    }
}

QPoint Tower2::getpos(){
    return _pos;
}
/*
void Tower::checkEnemyInRange()
{
    if (chooseEnemy)
    {
        if (!collisionWithCircle(_pos, attackRange, chooseEnemy->pos0()+QPoint(70,80), 1))
            lostSightOfEnemy();
    }
    else
    {
        // ��������,���Ƿ��е����ڹ�����Χ��
        QList<Enemy2*> enemyList = game->enemy2_list;
        foreach (Enemy2 *enemy, enemyList)
        {
            if (collisionWithCircle(_pos, attackRange, enemy->pos0(), 1))
            {
                chooseEnemyForAttack(enemy);
                break;
            }
        }
    }
}
*/

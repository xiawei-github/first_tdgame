#include "mybutton2.h"
#include <QPixmap>
#include <QPropertyAnimation>
#include <QPoint>
#include "tower.h"
#include "mywindow.h"
#include <cassert>

MyButton2::MyButton2(QString pix, QPoint pos,MyWindow*game) : QPushButton(0),_pos(pos),_game(game)
{
    QPixmap pixmap(pix);
    this->setFixedSize(60,60);
    this->setStyleSheet("QPushButton{border:0px;}");
    this->setIcon(pixmap);
    this->setIconSize(QSize(60,60));

    this->setContextMenuPolicy(Qt::ActionsContextMenu);
    QAction * action1 = new QAction(this);
    action1->setText("set defence tower");
    this->addAction(action1);
    connect(action1,&QAction::triggered,this,[=](){
        emit chooseSetTower();
    });

    QAction * action2 = new QAction(this);
    action2->setText("delete defence tower");
    this->addAction(action2);
    connect(action2,&QAction::triggered,this,[=](){
        emit chooseDeleteTower();
    });

    this->move(_pos.x(),_pos.y());
}

void MyButton2::set_tower1(){
    Tower * a_new_tower = new Tower(this->_pos+QPoint(35,-55),_game,":/tower.png");
    _game->tower_list.push_back(a_new_tower);
}

void MyButton2::set_tower2(){
    Tower * a_new_tower = new Tower(this->_pos+QPoint(-90,-55),_game,":/tower.png");
    _game->tower_list.push_back(a_new_tower);
}
/*
void MyButton2::delete_tower(Tower *tower){
    Q_ASSERT(tower);
    tower_list.removeOne(tower);
    delete tower;
}
*/

#include "mybutton3.h"
#include <QPixmap>
#include <QPropertyAnimation>

MyButton3::MyButton3(QString pix) : QPushButton(0)
{
    QPixmap pixmap(pix);
    this->setFixedSize(60,60);
    this->setStyleSheet("QPushButton{border:0px;}");
    this->setIcon(pixmap);
    this->setIconSize(QSize(60,60));
}

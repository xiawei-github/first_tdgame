#ifndef MYBUTTON2_H
#define MYBUTTON2_H
#include <QPoint>
#include <QWidget>
#include <QPushButton>
#include <QAction>
#include "mywindow.h"
#include "tower.h"

class MyWindow;
class Tower;
class MyButton2 : public QPushButton
{
    Q_OBJECT
public:
    MyButton2(QString pix, QPoint pos, MyWindow *game);
    void set_tower1();
    void set_tower2();
    void delete_tower(Tower * tower);
signals:
    void chooseSetTower();
    void chooseDeleteTower();
private:
    QPoint _pos;
    MyWindow * _game;
    QList<Tower*> tower_list;
public slots:
};

#endif // MYBUTTON2_H

#ifndef BULLET_H
#define BULLET_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QPropertyAnimation>
#include <QSize>
#include "enemy2.h"
#include "mywindow.h"

class MyWindow;
class Enemy2;
class Bullet : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint currentPos READ getCurrentPos WRITE setCurrentPos)
public:
    //Bullet(QPoint startPos, QPoint targetPos,int damage, Enemy2 * enemy, MyWindow * game, QString fileName);
    Bullet(QPoint startPos, QPoint targetPos,int damage, Enemy2 * enemy, MyWindow * game, const QPixmap &sprite = QPixmap(":/anniu2.png"));
    void draw(QPainter * painter);
    void move();
    QPoint getCurrentPos();
    void setCurrentPos(QPoint pos);
private:
    QPoint startPos;
    QPoint targetPos;
    QPoint currentPos;
    QPixmap pixmap;
    Enemy2 * enemy;
    MyWindow * game;
    int damage;
    static const QSize fixedSize;

signals:

private slots:
    void hitTarget();

public slots:
};

#endif // BULLET_H

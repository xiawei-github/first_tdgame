#include "waypoint.h"
#include <QPainter>
#include <QColor>

WayPoint::WayPoint(QPoint pos)
    : pos0(pos)
{
    this->nextWayPoint0 = NULL;
}

void WayPoint::setNextWayPoint(WayPoint *nextPoint){
    nextWayPoint0 = nextPoint;
}

WayPoint* WayPoint::nextWayPoint() const{
    return nextWayPoint0;
}

const QPoint WayPoint::pos() const{
    return pos0;
}

void WayPoint::draw(QPainter *painter) const{
    painter->save();
    painter->setPen(Qt::green);
    painter->drawEllipse(pos0, 6, 6);
    painter->drawEllipse(pos0, 2, 2);

    if(nextWayPoint0){
        painter->drawLine(pos0, nextWayPoint0->pos0);
    }
    painter->restore();
}


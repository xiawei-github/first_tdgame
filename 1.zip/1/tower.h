#ifndef TOWER_H
#define TOWER_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include <QTimer>
#include <QSize>
#include "enemy2.h"
#include "mywindow.h"
#include "bullet.h"

class QPainter;
class QTimer;
class Enemy2;
class MyWindow;
class Bullet;
class Tower : public QObject
{
    Q_OBJECT
public:
    Tower(QPoint pos, MyWindow * game, QString pixFileName);
    void draw(QPainter * painter);
    void targetKilled();
    void checkEnemyInRange();
    void attackEnemy();
    void chooseEnemyForAttack(Enemy2 *enemy);
    void lostSightOfEnemy();
    void levelup1();
    void levelup2();
    int level();
    QPoint getpos() const;

private:
    QPoint _pos;
    QPixmap pixmap;
    Enemy2 * chooseEnemy;
    QTimer * fireRateTimer;
    qreal rotationSprite;
    int attackRange;
    MyWindow * game;
    int fireRate;
    int	damage;
    bool attacking;
    int level0;
    static const QSize ms_fixedSize;

signals:

private slots:
    void shootWeapon();

public slots:
    //void shootWeapon();
};

#endif // TOWER_H


#ifndef ENEMY2_H
#define ENEMY2_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include "mywindow.h"
#include "tower.h"
#include <QList>
#include <QSize>
#include "waypoint.h"
#include "tower2.h"

class MyWindow;
class Tower;
class WayPoint;
class Tower2;
class Enemy2 : public QObject
{
    Q_OBJECT
public:
    //Enemy2(WayPoint *startWayPoint, MyWindow *game,QString fileName);
    Enemy2(WayPoint *startWayPoint, MyWindow *game, qreal speed, int blood, const QPixmap &sprite = QPixmap(":/enemy2.png"));
    void draw(QPainter * painter);
    void move();
    void setPos();
    void getDamage(int damage);
    void getRemoved();
    void getAttacked(Tower *attacker);
    void gotLostSight(Tower *attacker);
    void getStopped(qreal enemystop);
    QPoint pos[8];
    QPoint pos0() const;
    friend class Tower2;
private:
    QPoint startPos;
    QPoint targetPos;
    QPoint currentPos;
    QPixmap pixmap;
    qreal speed;
    qreal rotationSprite;
    qreal enemystop;
    //QPoint pos[8];
    int i=0;
    int currentBlood;
    int maxBlood;
    MyWindow * game;
    QList<Tower*> attackedTowersList;
    bool active;
    WayPoint * destinationWayPoint;
    static const QSize fixedSize;
    QPoint _pos;

signals:

public slots:
    void doActivate();
};

#endif // ENEMY2_H

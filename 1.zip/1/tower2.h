#ifndef TOWER2_H
#define TOWER2_H

#include <QObject>
#include <QPoint>
#include <QPixmap>
#include <QTimer>
#include <QSize>
#include "enemy2.h"
#include "mywindow.h"
#include "bullet.h"

class QPainter;
class QTimer;
class Enemy2;
class MyWindow;
class Bullet;
class Tower2 : public QObject
{
    Q_OBJECT
public:
    Tower2(QPoint pos, MyWindow * game, QString pixFileName);
    void draw(QPainter * painter);
    //void checkEnemyInRange();
    //void lostSightOfEnemy();
    QPoint getpos();
private:
    QPoint _pos;
    QPixmap pixmap;
    QList <Enemy2*> chosenEnemyList;
    int attackRange;
    qreal enemystop;
    static const QSize ms_fixedSize;
    MyWindow * game;

signals:

public slots:
    void chooseEnemyforAttack();
};

#endif // TOWER2_H

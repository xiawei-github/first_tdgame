#include "towerposition.h"
#include <QPainter>

const QSize TowerPosition::ms_fixedSize(100, 100);

TowerPosition::TowerPosition(QPoint pos, const QPixmap &sprite/* = QPixmap(":/anniu4.png")*/)
{
    this->hasTower0 = false;
    this->pos0 = pos;
    this->sprite = sprite;
    /*
    QSize picSize(100,100);
    QPixmap scaledPixmap = sprite.scaled(picSize,Qt::KeepAspectRatio);
    sprite = scaledPixmap;
    */
}
/*
TowerPosition::TowerPosition(QPoint pos, QString fileName): m_hasTower(false), m_pos(pos), m_sprite(sprite){
    QSize picSize(100,100);
    QPixmap scaledPixmap = sprite.scaled(picSize,Qt::KeepAspectRatio);
    m_sprite = scaledPixmap;
}
*/
const QPoint TowerPosition::centerPos() const{
    QPoint offsetPoint(ms_fixedSize.width() / 2, ms_fixedSize.height() / 2);
    return pos0 + offsetPoint;
}

bool TowerPosition::containPoint(const QPoint &pos) const{
    bool isXInHere = pos0.x() < pos.x() && pos.x() < (pos0.x() + ms_fixedSize.width());
    bool isYInHere = pos0.y() < pos.y() && pos.y() < (pos0.y() + ms_fixedSize.height());
    return isXInHere && isYInHere;
}

bool TowerPosition::hasTower() const{
    return hasTower0;
}

void TowerPosition::setHasTower(bool hasTower/* = true*/){
    hasTower0 = hasTower;
}

void TowerPosition::setHasnotTower(bool hasTower/* = false*/){
    hasTower = hasTower;
}

void TowerPosition::draw(QPainter *painter) const{
    painter->drawPixmap(pos0.x(), pos0.y(), sprite);
}


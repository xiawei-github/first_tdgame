#include "bullet.h"
#include <QDebug>

const QSize Bullet::fixedSize(8, 8);

Bullet::Bullet(QPoint startPos, QPoint targetPos,int damage, Enemy2 * enemy, MyWindow * game, const QPixmap &sprite/* = QPixmap(":/anniu2.png")*/) : QObject(0),pixmap(sprite){
    this->startPos = startPos;
    this->currentPos = startPos;
    this->targetPos = targetPos;
    this->enemy = enemy;
    this->game = game;
    this->damage = damage;
    QSize picSize(30,30);
    QPixmap scaledPixmap = pixmap.scaled(picSize,Qt::KeepAspectRatio);
    pixmap = scaledPixmap;
}

void Bullet::move()
{
    static const int duration = 100;
    QPropertyAnimation * animation = new QPropertyAnimation(this, "m_currentPos");
    animation->setDuration(duration);
    animation->setStartValue(startPos);
    animation->setEndValue(targetPos);
    connect(animation, SIGNAL(finished()), this, SLOT(hitTarget()));
    animation->start();
}

void Bullet::setCurrentPos(QPoint pos){
    this->currentPos = pos;
}

QPoint Bullet::getCurrentPos(){
    return this->currentPos;
}

void Bullet::draw(QPainter *painter){
    //qDebug()<<"draw";
    painter->drawPixmap(currentPos,pixmap);
}

void Bullet::hitTarget(){
    if(game->enemy2_list.indexOf(enemy)!=-1){
        enemy->getDamage(damage);
    }
    game->removedBullet(this);
}

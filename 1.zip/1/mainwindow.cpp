#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QTimer>
#include "mybutton.h"
#include "mywindow.h"
#include <QMediaPlayer>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    this->setFixedSize(1500,900);
    ui->setupUi(this);
    MyButton * btn1 = new MyButton(":/roundonebutton.png");
    btn1->setParent(this);
    btn1->move(700,100);
    MyWindow * scene1 = new MyWindow(1);
    connect(btn1,&QPushButton::clicked,this,[=](){
        btn1->zoomdown();
        btn1->zoomup();
        QTimer::singleShot(500,this,[=](){
            this->hide();
            scene1->show();
        });
    });
    connect(scene1,&MyWindow::chooseBack,this,[=](){
        scene1->hide();
        this->show();
    });

    MyButton * btn2 = new MyButton(":/roundtwobutton.png");
    btn2->setParent(this);
    btn2->move(700,300);
    MyWindow * scene2 = new MyWindow(2);
    connect(btn2,&QPushButton::clicked,this,[=](){
        btn2->zoomdown();
        btn2->zoomup();
        QTimer::singleShot(500,this,[=](){
            this->hide();
            scene2->show();
        });
    });
    connect(scene2,&MyWindow::chooseBack,this,[=](){
        scene2->hide();
        this->show();
    });

    QMediaPlayer * player = new QMediaPlayer;
    player->setMedia(QUrl("qrc:/BeautifulHawaii_Full.mp3"));
    player->setVolume(30);
    player->play();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/timg.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}

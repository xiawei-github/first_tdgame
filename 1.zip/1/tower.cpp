#include "tower.h"
#include <QPoint>
#include <QPixmap>
#include <QPainter>
#include <QVector2D>
#include <QtMath>
#include <QColor>
#include <QTimer>
#include "utility.h"

const QSize Tower::ms_fixedSize(42, 42);

Tower::Tower(QPoint pos, MyWindow * game, QString pixFileName) : QObject(0),pixmap(pixFileName)
{
    this->attackRange = 300;
    this->_pos = pos;
    this->game = game;
    this->attacking = false;
    this->damage = 10;
    this->fireRate = 1000;
    this->rotationSprite = 0.0;
    this->chooseEnemy = NULL;
    this->level0 = 1;
    QSize picSize(120,160);
    QPixmap scaledPixmap = pixmap.scaled(picSize,Qt::KeepAspectRatio);
    pixmap = scaledPixmap;
    fireRateTimer = new QTimer(this);
    connect(fireRateTimer,SIGNAL(timeout()),this,SLOT(shootWeapon()));
}

void Tower::draw(QPainter *painter){
    painter->save();
    painter->setPen(Qt::white);
    painter->drawEllipse(_pos + QPoint(30, -20), attackRange, attackRange);
    //painter->drawPixmap(_pos,pixmap);
    // ����������ѡ������
    //painter->translate(_pos);
    //painter->rotate(rotationSprite);
    painter->drawPixmap(_pos + QPoint(5,-105), pixmap);
    painter->restore();
}

void Tower::targetKilled(){
    if (chooseEnemy){
        chooseEnemy = NULL;
    }
    fireRateTimer->stop();
    rotationSprite = 0.0;
}

void Tower::checkEnemyInRange(){
    if (chooseEnemy){
        // ���������,��Ҫ��ת��̨��׼����
        // ������׼��
        //QVector2D normalized(chooseEnemy->pos() - _pos);
        //normalized.normalize();
        //rotationSprite = qRadiansToDegrees(qAtan2(normalized.y(), normalized.x())) - 90;
        // ����������빥����Χ
        if (!collisionWithCircle(_pos, attackRange, chooseEnemy->pos0()+QPoint(70,80), 1))
            lostSightOfEnemy();
    }
    else{
        // ��������,���Ƿ��е����ڹ�����Χ��
        QList<Enemy2*> enemyList = game->enemy2_list;
        foreach(Enemy2 *enemy, enemyList){
            if (collisionWithCircle(_pos, attackRange, enemy->pos0(), 1)){
                chooseEnemyForAttack(enemy);
                break;
            }
        }
    }
}

void Tower::attackEnemy(){
    fireRateTimer->start(fireRate);
}

void Tower::chooseEnemyForAttack(Enemy2 *enemy){
    chooseEnemy = enemy;
    attackEnemy();
    chooseEnemy->getAttacked(this);
}

void Tower::lostSightOfEnemy(){
    chooseEnemy->gotLostSight(this);
    if (chooseEnemy){
        chooseEnemy = NULL;
    }
    fireRateTimer->stop();
    rotationSprite = 0.0;
}

void Tower::shootWeapon(){
    QPoint pos1 = chooseEnemy->pos0();
    QPixmap pixmap(":/anniu2.png");
    Bullet *bullet = new Bullet(_pos+QPoint(45,-30), pos1, damage, chooseEnemy, game,pixmap);
    bullet->move();
    game->addBullet(bullet);
}

void Tower::levelup1(){
    level0++;
    damage=15;
    attackRange=420;
    fireRate=800;
}
void Tower::levelup2(){
    level0++;
    damage=20;
    attackRange=480;
    fireRate=600;
}
int Tower::level(){
    return level0;
}

QPoint Tower::getpos() const{
    return  _pos;
}
